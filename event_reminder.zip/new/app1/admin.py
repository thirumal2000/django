from django.contrib import admin

from .models import Venue
from .models import myclubuser
from .models import event


#admin.site.register(Venue)
admin.site.register(myclubuser)


@admin.register(Venue)
class Venueadmin(admin.ModelAdmin):
    list_display=('name','address','phone')
    list_filter=['phone']
    search_fields=['name']

@admin.register(event)
class eventdis(admin.ModelAdmin):
    list_display=('name','event_date')
    list_filter=['event_date']
    search_fields=['event_date']