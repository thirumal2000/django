from django import forms
from django.forms import widgets
from .models import Venue,event

class EventFormAdmin(forms.ModelForm):
    class Meta:
        model = event
        fields = ('name','event_date','venue','manager','attendees','description')
        labels={
            'name':'',
            'event_date':'YYYY-MM-DD HH:MM:SS',
            'venue':'venue',
            'manager':'manager',
            'attendees':'attendes',
            'discription':'',
            
        }
        widgets={
            'name':forms.TextInput(attrs={'class':'form-control','placeholder':'event name'}),
            'event_date':forms.TextInput(attrs={'class':'form-control','placeholder':'evenr date'}),
            'venue':forms.Select(attrs={'class':'form-select','placeholder':'venue'}),
            'manager':forms.Select(attrs={'class':'form-select','placeholder':'manager'}),
            'attendees':forms.SelectMultiple(attrs={'class':'form-control','placeholder':'attendes'}),
            'description':forms.Textarea(attrs={'class':'form-control','placeholder':'discription'}),
            
        }
class EventForm(forms.ModelForm):
    class Meta:
        model = event
        fields = ('name','event_date','venue','manager','attendees','description')
        labels={
            'name':'',
            'event_date':'YYYY-MM-DD HH:MM:SS',
            'venue':'venue',
            'attendees':'attendes',
            'discription':'',
            
        }
        widgets={
            'name':forms.TextInput(attrs={'class':'form-control','placeholder':'event name'}),
            'event_date':forms.TextInput(attrs={'class':'form-control','placeholder':'evenr date'}),
            'venue':forms.Select(attrs={'class':'form-select','placeholder':'venue'}),
            'attendees':forms.SelectMultiple(attrs={'class':'form-control','placeholder':'attendes'}),
            'description':forms.Textarea(attrs={'class':'form-control','placeholder':'discription'}),
            
        }
    


class VenueForm(forms.ModelForm):
    class Meta:
        model = Venue
        fields = ('name','address','zip_code','phone','web','email_address')
        labels={
            'name':'',
            'address':'',
            'zip_code':'',
            'phone':'',
            'web':'',
            'email_address':'',
        }
        widgets={
            'name':forms.TextInput(attrs={'class':'form-control','placeholder':'name'}),
            'address':forms.TextInput(attrs={'class':'form-control','placeholder':'addres'}),
            'zip_code':forms.TextInput(attrs={'class':'form-control','placeholder':'pincode'}),
            'phone':forms.TextInput(attrs={'class':'form-control','placeholder':'phone'}),
            'web':forms.TextInput(attrs={'class':'form-control','placeholder':'web'}),
            'email_address':forms.TextInput(attrs={'class':'form-control','placeholder':'email'}),
        }
    
        
        