from django.shortcuts import redirect, render
import calendar
from .forms import VenueForm,EventForm,EventFormAdmin
from calendar import HTMLCalendar
from datetime import datetime
from django.http import HttpResponseRedirect, response
from .models import event,Venue
from django.contrib.auth.models import User
from django.http import HttpResponse
import csv
from django.http import FileResponse
from django.core.paginator import Paginator
import io
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib.pagesizes import letter
from django.contrib import messages

def my_events(request):
    if request.user.is_authenticated:
        me = request.user.id
        print(me)
        events = event.objects.filter(manager=me)
        return render(request,'my_event.html',{'events':events})
    else:
        messages.success(request,"you are not authorised to view this page")
        return redirect('home')


    
def venue_pdf(request):
    if request.user.is_authenticated:
        buf = io.BytesIO()
        c = canvas.Canvas(buf,pagesize=letter,bottomup=0)
        textob = c.beginText()
        textob.setTextOrigin(inch,inch)
        textob.setFont("Helvetica",14)
        venues =Venue.objects.all()
        lines=[]
        for venue in venues:
            lines.append(venue.name)
            lines.append(venue.address)
            lines.append(venue.zip_code)
            lines.append(venue.phone)
            lines.append(venue.web)
            lines.append(venue.email_address)
            lines.append("===========================")
        for line in lines:
            textob.textLine(line)
        c.drawText(textob)
        c.showPage()
        c.save()
        buf.seek(0)
        
        return FileResponse(buf,as_attachment=True,filename='venue.pdf')
    else:
        return render(request,"login_msg.html")
    
    
    
def venue_csv(request):
    if request.user.is_authenticated:
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename=venue.csv' 
        writer=csv.writer(response)
        lines = []
        venues=Venue.objects.all()
        writer.writerow(['Venue Name','Address','Zip_code','Phone','Web Address','Email'])
        for venue in venues:
            writer.writerow([venue.name,venue.address,venue.zip_code,venue.phone,venue.web,venue.email_address])
        response.writelines(lines)
        return response
    else:
        return render(request,"login_msg.html")


def venue_text(request):
    if request.user.is_authenticated:
        response = HttpResponse(content_type='text/plain')
        response['Content-Disposition'] = 'attachment; filename=venue_name.txt'
        lines = []
        venues=Venue.objects.all()
        for venue in venues:
            lines.append(f'{venue}\n{venue.address}\n{venue.phone}\n')
        response.writelines(lines)
        return response
    else:
        return render(request,"login_msg.html")



def delete_venue(request,venue_id):
    
    event1=Venue.objects.get(pk=venue_id)
    event1.delete()
    return redirect('list_venues')

def delete_event(request,event_id):
    event1=event.objects.get(pk=event_id)
    if request.user == event.manager:
        event1.delete()
        messages.success(request,"event deleted succefully")
        return redirect('list_events')
    else:
        messages.success(request,"you are not authorised to delete")
        return redirect('list_events')
        
def update_event(request,event_id):
    events=event.objects.get(pk=event_id)
    form= EventForm(request.POST or None,instance=events)
    if form.is_valid():
        form.save()
        return redirect('list_events')
    return render(request,'update_event.html',{'events':events,'form':form})



def add_event(request):
    submitted=False
    if request.method=="POST":
        if request.user.is_superuser:
            form = EventFormAdmin(request.POST)
            if form.is_valid():
                form.save()
                return HttpResponseRedirect('add_event?submitted=True')
        else:
            form = EventFormAdmin(request.POST)
            event = form.save(commit=False)
            event.manager = request.user
            event.save()
            if form.is_valid():
                #form.save()
                event = form.save(commit=False)
                event.manager = request.user
                event.save()
                return HttpResponseRedirect('adifd_event?submitted=True')
       
    else:
        if request.user.is_superuser:
            form = EventFormAdmin
        else:
            form = EventForm
        form = EventForm
        if 'submitted' in request.GET:
            submitted=True
    return render(request,'add_event.html',{'form':form,'submitted':submitted})

def update_event(request,event_id):
    events=event.objects.get(pk=event_id)
    form= EventForm(request.POST or None,instance=events)
    if form.is_valid():
        form.save()
        return redirect('list_events')
    return render(request,'update_event.html',{'events':events,'form':form})

def update_venue(request,venue_id):
    venue=Venue.objects.get(pk=venue_id)
    if request.user.is_superuser:
        form= VenueForm(request.POST or None,instance=venue)
    else:
        form= VenueForm(request.POST or None,instance=venue)
    if form.is_valid():
        form.save()
        return redirect('list_venues')
    return render(request,'update_venue.html',{'venue':venue,'form':form})
    
def search_venues(request):
    if request.method=="POST":
        searched = request.POST['searched']
        venues = Venue.objects.filter(name__contains=searched)
        
        return render(request,'search_venues.html',{'searched':searched,'venues':venues })
    else:
        return render(request,'search_venues.html',{})

def show_venue(request,venue_id):
    venue=Venue.objects.get(pk=venue_id)
    #venue_owner = User.objects.get(pk=Venue.owner)
    return render(request,'show_venue.html',{'venue':venue})


def list_venues(request):
    venue_list=Venue.objects.all()
    p = Paginator(Venue.objects.all(),3)
    page= request.GET.get('page')
    venues = p.get_page(page)
    nums = "1"*venues.paginator.num_pages
    return render(request,'venue.html',{'venue_list':venue_list,'venues':venues,'nums':nums,'len':len(venue_list)})

def add_venue(request):
    submitted=False
    if request.method=="POST":
        form = VenueForm(request.POST)
        if form.is_valid():
            #form.save()
            venue = form.save(commit=False)
            venue.owner = request.user.id
            venue.save()
            
            return HttpResponseRedirect('add_venue?submitted=True')
    else:
        form = VenueForm
        if 'submitted' in request.GET:
            submitted=True
    return render(request,'add_venue.html',{'form':form,'submitted':submitted})
    

def all_events(request):
    event_list = event.objects.all().order_by('event_date')
    return render(request,'events_list.html',{'event_list':event_list})

def home(request,year=datetime.now().year ,month=datetime.now().strftime('%B') ):
    name = "john"
    month = month.capitalize()
    month_number=list(calendar.month_name).index(month)
    month_number=int(month_number)
    cal=HTMLCalendar().formatmonth(year,month_number)
    now=datetime.now()
    currentyear=now.year
    #time =now.strftime("%I %M %P")
    return render(request,'home.html',{
                  "name":name,
                  "year":year,
                  "month":month,
                  "month_number":month_number,
                  "cal":cal,
                  "now":now,
                  "currentyear":currentyear
                  })
