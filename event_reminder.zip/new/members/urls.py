
from django.urls import path
from django.urls.conf import include
from . import views

urlpatterns = [
    path('login_users', views.login_user,name="login"),
    path('register_user',views.register_user,name="register_user"),
    path('logout_user',views.logout_user,name="logout")
    
]